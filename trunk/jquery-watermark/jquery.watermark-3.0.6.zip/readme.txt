Watermark plugin for jQuery
Copyright � 2009-2010 Todd Northrop
http://www.speednet.biz/

Last updated May 9, 2010

This simple-to-use jQuery plugin adds watermark capability to HTML
input elements.

Dual licensed under the MIT or GPL Version 2 licenses.
See mit-license.txt and gpl2-license.txt in the project root for details.

See changelog.txt for a summary of changes to the project.

Project page:
http://jquery-watermark.googlecode.com/

Please see the project page for all usage instructions and notes.

About the Author
	Todd Northrop is the owner and developer of Lottery Post, the
	world's largest community of lottery players and home to the
	#1 lottery results service worldwide. (www.lotterypost.com)
	He founded his company, Speednet Group, in 2000.

__
